/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClienteServidor;

import ThreadClienteUDP.ThreadCliente1;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Guilherme
 */
public class ThreadServidorTCP extends Thread {

    public void run() {
        try {
            //parte do servidor que retorna o arquivo que o cliente pediu.
            
            ServerSocket server = new ServerSocket(55557);

            Socket clSocket = server.accept();
            InputStream in = clSocket.getInputStream();
            InputStreamReader isr = new InputStreamReader(in);
            BufferedReader reader = new BufferedReader(isr);
            String fName = reader.readLine();
            System.out.println("kkkkk" + fName);

            File f1 = new File("C:\\Users\\Guilherme\\Desktop\\ArquivosServidor//" + fName);
            FileInputStream out = new FileInputStream(f1);

            OutputStream oute = clSocket.getOutputStream();
            OutputStreamWriter osw = new OutputStreamWriter(oute);

            BufferedWriter writer = new BufferedWriter(osw);

            writer.write(fName + "\n");

            writer.flush();
            
            int c;
            while ((c = out.read()) != -1) {
                oute.write(c);
            }

            server.close();
            
            //ThreadServidorTCP servidor = new ThreadServidorTCP();
            //servidor.start();

        } catch (FileNotFoundException ex) {
            Logger.getLogger(ThreadCliente1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ThreadCliente1.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
