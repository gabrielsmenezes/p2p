/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClienteServidor;

import ThreadClienteUDP.ThreadCliente1;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import View.BuscarArquivos;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import View.ListarArquivos;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 *
 * @author Guilherme
 */
public class ThreadServidorUDP extends Thread {

    int numeroRequisicao;
    DatagramSocket ds;
    byte[] msg = new byte[4096];
    DatagramPacket pkg;
String endereco;
int l = 0;
//Lista Usuarios
public void requisicao1(String endereco) throws  InterruptedException, IOException{
    byte[] msg = new byte[6000];
                System.out.println("Pacode do servidor recebido");
                
                InetAddress ipAddr = InetAddress.getLocalHost();
                msg = ipAddr.getHostAddress().getBytes();
                String ipCliente = new String(msg);
                DatagramSocket ds = new DatagramSocket();
                DatagramPacket pkg = new DatagramPacket(msg, msg.length, InetAddress.getByName(endereco), 5588);
                System.out.println("Pacote do servidor recriado");
                
                ds.send(pkg);
                System.out.println("Pacote do servidor enviado");
                ds.close();
                sleep(100);
                if(ds.isClosed()){
                   //servidor(); 
                }
                
                
    
}

//Lista de Arquivos
public void requisicao2(String endereco) throws IOException, InterruptedException{

                //recebe requisição para retornar lista de arquivos
                InetAddress ipAddr = InetAddress.getLocalHost();
                String ipCliente = new String(ipAddr.getHostAddress().getBytes());
                byte[] ipservidor = ipAddr.getHostAddress().getBytes();
                File file = new File("C:\\Users\\Guilherme\\Desktop\\ArquivosServidor");
                File[] arquivos = file.listFiles();
                
               //
                
                
                //envia lista de arquivos
                 ipCliente = new String(msg);
                 ipAddr = InetAddress.getLocalHost();
                 ipservidor = ipAddr.getHostAddress().getBytes();
                 arquivos = file.listFiles();
                
                
                
                String Nome;
                String Tamanho;
                String  arquivos1= ""; 
                int posicao1 = 0;
                
                for (File fileTmp : arquivos) {
                    long kbSize = fileTmp.length() / 1024;
                    Nome = fileTmp.getName();
                    Tamanho = "" + kbSize;
                    String ipServidor = new String(ipservidor);
                    String nome = new String(Nome);
                    String tamanho = new String(Tamanho);
                    arquivos1 += ipServidor+","+nome+","+tamanho+";";
                    if(posicao1 == arquivos.length){
                        arquivos1+=ipServidor+","+nome+","+tamanho;
                    }
                    
                    posicao1++;
                }
                DatagramSocket ds = new DatagramSocket();
                    msg = (arquivos1).getBytes();
                    pkg = new DatagramPacket(msg, msg.length, InetAddress.getByName(endereco), 5588);
                    System.out.println("Pacote do servidor recriado");
                    
                    ds.send(pkg);
                    System.out.println("Pacote do servidor enviado");
                    //System.out.println(new String(pkg.getData()));
                   
                    ds.close();
                

                
                ds.close();

sleep(100);
//servidor();

    
}

    public void servidor() throws SocketException, IOException, UnknownHostException, InterruptedException {
        
        
            DatagramSocket ds = new DatagramSocket(5588);
        
            
         
        
        
        ds.setBroadcast(true);

        pkg = new DatagramPacket(msg, msg.length);
        System.out.println("Pacote do servidor cirado");
        ds.receive(pkg);
        endereco = pkg.getAddress().getHostAddress();
        ds.close();
        
        byte[] mensagem = pkg.getData();
        String requisicao = new String(pkg.getData()).trim();
        System.out.println(requisicao);
        numeroRequisicao = new Integer(requisicao);
  
                System.out.println(numeroRequisicao);
                l++;
                //Lista Usuarios
                if (numeroRequisicao == 1) {
                    requisicao1(endereco);
            }
                //Lista de Arquivos
                if (numeroRequisicao == 2) {
                    requisicao2(endereco);
            }
                
                
                
                
}
               
        



    public void run() {

        try {
            servidor();
            
            

            
            

        } catch (FileNotFoundException ex) {
            Logger.getLogger(ThreadCliente1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ThreadCliente1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(ThreadServidorUDP.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
