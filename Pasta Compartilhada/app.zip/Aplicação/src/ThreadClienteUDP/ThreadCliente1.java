/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ThreadClienteUDP;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
 import java.util.concurrent.TimeUnit;
import static java.util.concurrent.TimeUnit.MILLISECONDS;
/**
 *
 * @author Guilherme
 */
public class ThreadCliente1 extends Thread {

    /*
    Requisição = 1-- Lista Usuários
    Requisição = 2-- Lista Arquivos
    Requisição = 3-- Busca Arquivos
     */
    int requisicao;
    String[] ipUsuario;
    String ipBuscarArquivos;
    String nomeBuscarArquivos;
    String[] arquivosServidor;
    int tamanho;

    public int getTamanho() {
        return tamanho;
    }

    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }

    public int getRequisicao() {
        return requisicao;
    }

    public void setRequisicao(int requisicao) {
        this.requisicao = requisicao;
    }

    public String[] getIpUsuario() {
        return ipUsuario;
    }

    public void setIpUsuario(String[] ipUsuario) {
        this.ipUsuario = ipUsuario;
    }

    public String getIpBuscarArquivos() {
        return ipBuscarArquivos;
    }

    public void setIpBuscarArquivos(String ipBuscarArquivos) {
        this.ipBuscarArquivos = ipBuscarArquivos;
    }

    public String getNomeBuscarArquivos() {
        return nomeBuscarArquivos;
    }

    public void setNomeBuscarArquivos(String nomeBuscarArquivos) {
        this.nomeBuscarArquivos = nomeBuscarArquivos;
    }

    public String[] getArquivosServidor() {
        return arquivosServidor;
    }

    public void setArquivosServidor(String[] arquivosServidor) {
        this.arquivosServidor = arquivosServidor;
    }
    


    public void run() {

        
        try {
           // DatagramSocket socket = new DatagramSocket();
            //Lista Usuários 
            if (getRequisicao() == 1) {
                //envia valor de requisição
                //socket = new DatagramSocket();
                 DatagramSocket socket = new DatagramSocket();
                int numeroRequisicao = getRequisicao();
                String req = Integer.toString(numeroRequisicao);

                System.out.println("ei");
                System.out.println(req);

                byte[] mensagem = req.getBytes();
                InetAddress addr = InetAddress.getByName("255.255.255.255");
                DatagramPacket pacote = new DatagramPacket(mensagem, mensagem.length, addr, 5588);
                System.out.println("Pacote do cliente criado");
                 
                socket.send(pacote);
                socket.close();
                

                //recebe ip dos usuários
                mensagem = new byte[6000];
                System.out.println("Pacote do cliente enviador");
                pacote = new DatagramPacket(mensagem, mensagem.length);
                
                String[] ipUsuarios = new String[10];

                
                
                int posicao = 0;
                 DatagramSocket socket1 = new DatagramSocket(5588);
                
                while (true) {
                    sleep(100);
                    System.out.println("Cliente Esperando...");
                  
                    if(posicao!=0){
                      socket1 = new DatagramSocket(5588);  
                    }
                     
                     socket1.setSoTimeout(1000);
                    System.out.println("Cliente Esperando1...");
                    socket1.receive(pacote);
                    System.out.println("Cliente Esperando2...");
                    
                    if(pacote.getData()==null){
                        break;
                    }
                    
                    socket1.close();
                    System.out.println("Pacote do cliente recebido");

                    
                   
                    
                    if (pacote.getData() != null) {
                        ipUsuarios[posicao] = new String(pacote.getData()).trim();
                        setIpUsuario(ipUsuarios);
                        System.out.println("setou");
                        pacote = new DatagramPacket(mensagem, mensagem.length);
                        socket1.close();
                        System.out.println(socket1.isClosed());
                        
                        posicao++;
                    }
                    posicao++;
                    socket1.close();
                    
                }

            }

            //Lista Arquivos
            if (getRequisicao() == 2) {
                DatagramSocket socket = new DatagramSocket();
                //envia valor de requisição.
                int numeroRequisicao = getRequisicao();
                String req = Integer.toString(numeroRequisicao);

                byte[] mensagem = req.getBytes();
                InetAddress addr = InetAddress.getByName("255.255.255.255");
                DatagramPacket pacote = new DatagramPacket(mensagem, mensagem.length, addr, 5588);
                System.out.println("Pacote do cliente criado");
                 
                socket.send(pacote);
                System.out.println("Pacote so cliente enviado");
                socket.close();

                
                

                
                

                //recebe lista de arquivos.
                
                
                int h = 0;
                String [] arquivosProntos = new String[100];
                String  arquivoNaoPronto;
                
                
                    
                    byte[] mensagem2 = new byte[10000];
                    
                    pacote = new DatagramPacket(mensagem2, mensagem2.length);
                    System.out.println("Cliente Esperando...");
                    
                     
                    
                    int posicao1 = 0;
                    
                    
                    //if(false){
                      //  socket2.close();
                    //}
                    DatagramSocket socket2 = new DatagramSocket(5588);
                    
                    while (true) {
                        
                        if(posicao1!=0){
                            socket2 = new DatagramSocket(5588);
                        }
                         
                        
                        
                        
                        socket2.setSoTimeout(1000);
                    socket2.receive(pacote);
                    socket2.close();
                    
                    if(pacote.getData()==null){
                        break;
                    }
                    
                    System.out.println("Pacote do cliente recebido");
                    //socket1.close();
                    
                    

                    arquivoNaoPronto = new String(pacote.getData());
                    
                    arquivosProntos = arquivoNaoPronto.split(";");
                    
                    
                    
                    
                    if (pacote.getData() != null) {
                        setArquivosServidor(arquivosProntos);
                        System.out.println("setour");
                        mensagem2 = new byte[1000];
                        pacote = new DatagramPacket(mensagem, mensagem.length);
                        socket2.disconnect();
                        socket2.close();
                        
                        posicao1++;
                        // System.out.println(arq[h]);

                    }
                    
                    h++;
                    posicao1++;
                    socket2.close();
                    System.out.print("passou close1");
                    socket2.close();
                    socket2 = new DatagramSocket(null);
                    
                }
                socket2.close();
                socket.close();
                System.exit(0);
                //System.out.print("passou close");

            }

            // Busca Arquivos
            if (getRequisicao() == 3) {

                //envia requisição para receber arquivos
                System.out.println("run1");

                String fName = getNomeBuscarArquivos();
                String fIp = getIpBuscarArquivos();
                System.out.println("" + fName);

                Socket socket1 = new Socket(fIp, 55557);

                OutputStream out = socket1.getOutputStream();
                OutputStreamWriter osw = new OutputStreamWriter(out);

                BufferedWriter writer = new BufferedWriter(osw);

                writer.write(fName + "\n");

                writer.flush();
                
                //recebo arquivo
                InputStream in = socket1.getInputStream();
                InputStreamReader isr = new InputStreamReader(in);
                BufferedReader reader = new BufferedReader(isr);
                String Name = reader.readLine();

                File f1 = new File("C:\\Users\\Guilherme\\Desktop\\ArquivosCliente\\" + Name);
                FileOutputStream out1 = new FileOutputStream(f1);
                int c;
                while ((c = in.read()) != -1) {
                    System.out.println(c);
                    out1.write(c);

                }
                socket1.close();
                out1.close();

            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(ThreadCliente1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ThreadCliente1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(ThreadCliente1.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
