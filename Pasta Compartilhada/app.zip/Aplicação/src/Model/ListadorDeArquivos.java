/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.File;

public class ListadorDeArquivos {

public static void main(String args[])

{

 File file = new File("C:\\Users\\201619060655\\Downloads");
 File[] arquivos = file.listFiles();

 for (File fileTmp : arquivos) {
     System.out.println(fileTmp.getName());
   }
 }
}